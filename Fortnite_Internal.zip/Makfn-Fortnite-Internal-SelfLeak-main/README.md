# Makfn-Fortnite-Internal-SelfLeak
Makfn Internal i made but im deciding to selfleak because its laggy as hell and crashes every second,,
now you skids can go and inject it with ritz injector.
Made by LeProxy.. https://discord.gg/makfn 

https://cdn.discordapp.com/attachments/998301486222159893/1046125894655279345/Fortnite_2022.11.26_-_19.00.56.50.DVR.1669485801515.mp4
https://cdn.discordapp.com/attachments/998301486222159893/1046125903547203674/Fortnite_2022.11.26_-_18.59.58.49.DVR.1669486112226.mp4
