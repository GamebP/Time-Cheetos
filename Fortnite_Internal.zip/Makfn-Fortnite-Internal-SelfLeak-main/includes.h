#pragma once



//#include <MinHook.h>
//#pragma comment(lib, "minhook.lib")

#include <d3d11.h>
#pragma comment(lib, "d3d11.lib")

#include "sdkdefines.h"
#include "sdk.h"
#include "safecall.h"